from django.db import models

# Create your models here.

from django.contrib.auth.models import AbstractUser


ROLE_CHOICES = (
    ('ADMIN', 'Admin'),
    ('OWNER', 'Owner'),
    ('TENANT', 'Tenant'),
)

class User(AbstractUser):
    email = models.EmailField(unique=True)
    role = models.CharField(max_length=10, choices=ROLE_CHOICES)
    is_active = models.BooleanField(default=True)  # Only active users can login

    def __str__(self):
        return self.username

class Society(models.Model):
    name = models.CharField(max_length=100)
    address = models.TextField()

    def __str__(self):
        return self.name

class Flat(models.Model):
    flat_number = models.CharField(max_length=10)
    society = models.ForeignKey(Society, on_delete=models.CASCADE)
    owner = models.ForeignKey(User, on_delete=models.CASCADE, limit_choices_to={'role':'OWNER'})

    def __str__(self):
        return f"{self.flat_number} - {self.society.name}"

STATUS_CHOICES = (
    ('PAID', 'Paid'),
    ('UNPAID', 'Unpaid')
)

class MaintenanceBill(models.Model):
    flat = models.ForeignKey(Flat, on_delete=models.CASCADE)
    month = models.CharField(max_length=20)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    status = models.CharField(max_length=10, choices=STATUS_CHOICES)

    def __str__(self):
        return f"{self.flat.flat_number} - {self.month} - {self.status}"
