
from django.contrib import admin
from django.urls import path
from core import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('login/', views.user_login, name='login'),
    path('logout/', views.user_logout, name='logout'),
    path('admin_dashboard/', views.admin_dashboard, name='admin_dashboard'),
    path('owner_dashboard/', views.owner_dashboard, name='owner_dashboard'),
    path('tenant_dashboard/', views.tenant_dashboard, name='tenant_dashboard'),
    path('create_owner/', views.create_owner, name='create_owner'),
]
