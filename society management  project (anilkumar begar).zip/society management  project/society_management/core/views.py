
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required

def user_login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user and user.is_active:
            login(request, user)
            if user.role == 'ADMIN':
                return redirect('admin_dashboard')
            elif user.role == 'OWNER':
                return redirect('owner_dashboard')
            elif user.role == 'TENANT':
                return redirect('tenant_dashboard')
        else:
            return render(request, 'login.html', {'error': 'Invalid credentials or inactive user'})
    return render(request, 'login.html')


def user_logout(request):
    logout(request)
    return redirect('login')


@login_required
def admin_dashboard(request):
    return render(request, 'admin_dashboard.html')

@login_required
def owner_dashboard(request):
    return render(request, 'owner_dashboard.html')

@login_required
def tenant_dashboard(request):
    return render(request, 'tenant_dashboard.html')

@login_required
def create_owner(request):
    return render(request, 'create_owner.html')
